package fr.loicmathieu.demo.quarkus.rest;

import io.quarkus.test.junit.SubstrateTest;

@SubstrateTest
public class NativePersonRestIT extends PersonRestTest {

    // Execute the same tests but in native mode.
}